export FLASK_APP=prefix.py
export FLASK_RUN_PORT=3308
export FLASK_DEBUG=true
export FLASK_ENV=development

export PYTHONPATH='.'

echo "completed setup"
