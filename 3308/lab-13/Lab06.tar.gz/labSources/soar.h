#ifndef soar_h
#define soar_h

#include <math.h>

double sigmoid(double input);
#endif
