#ifndef intercedes_h
#define intercedes_h

#include <stdbool.h>

bool leapWeek(int year);

int marine(int year);
#endif
